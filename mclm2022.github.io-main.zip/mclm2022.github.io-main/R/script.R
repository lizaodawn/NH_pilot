x <- "New variable called x"
print(x)
